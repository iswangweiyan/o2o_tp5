<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class Email{
    Public static function send(){
        $mail = new PHPMailer(true);
        try {
        // 服务器设置
        //$mail->SMTPDebug = 2;                                 // 开启Debug 发送邮件时关闭
        $mail->isSMTP();                                        // 使用SMTP
        $mail->Host = 'smtp.126.com';                           // 服务器地址
        $mail->SMTPAuth = true;                                 // 开启SMTP验证
        $mail->Username = 'youremailname@126.com';              // SMTP 用户名（你要使用的邮件发送账号）
        $mail->Password = 'youremailpassword';                  // SMTP 密码
        $mail->SMTPSecure = 'tls';                              // 开启TLS 可选
        $mail->Port = 25;                                       // 端口

        // 收件人
        $mail->setFrom('youremailname@126.com', 'nick');        // 来自收件人      nick <youremailname@126.com>
        $mail->addAddress('youremailname@qq.com', 'name');      // 添加一个收件人
        $mail->addReplyTo('youremailname@163.com', 'nick1');        // 回复地址(点回复按钮后，出现在收件人栏) nick1<youremailname@163.com>
        // $mail->addCC('cc@example.com');
        // $mail->addBCC('bcc@example.com');

        // 附件
        $mail->addAttachment('D:\xampp7013\htdocs\Test\public\static\index\image\odbc.png', 'new.jpg'); // 添加附件(填绝对路径) 
        //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // 可以设定名字

        // 内容
        $mail->isHTML(true);                                    // 设置邮件格式为HTML
        $mail->Subject = '欢迎注册成为ABCD网站会员';           //标题
        $mail->Body    = '您是第<b>12345678</b>名成员。';      //正文
        $mail->AltBody = 'DDDDDDDDxxX';                         //不清楚是干什么的

        $mail->send();
        echo '邮件发送成功。<br>';
        } catch (Exception $e) {
            echo '邮件发送失败。<br>';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        }
    }
}
