<?php
/**
 * 发送邮件相关配置
 */
return [
    'host' => 'smtp.126.com',
    'port' => 25,
    'username' => 'singwa3@126.com',
    'password' => 'you password o hah',

];
