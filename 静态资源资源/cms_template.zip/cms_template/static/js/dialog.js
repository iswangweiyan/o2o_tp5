var dialog={
	/*成功提示  顶层窗口*/
	success:function(message,url){
		if(dialog.isTopWin(window)){
			dialog.successMsg(message,url);
		}else{
			window.top.iframe.parent.dialog.successMsg(message,url);
		}
	},
	/*成功提示*/
	successMsg : function(message,url){
			layer.msg(message, {
			  icon: 1,
			  time:2000,
			}, function(){
				if(url){
					dialog.jump(url);
				}
			});  
	},
	/*成功提示 顶层窗口*/
	error:function(message,url){
		if(dialog.isTopWin(window)){
			dialog.errorMsg(message,url);
		}else{
			window.top.iframe.parent.dialog.errorMsg(message,url);
		}
	},
	 /*错误提示*/
	errorMsg : function(message,url){
		layer.msg(message, {
		  icon: 2,
		  time:2000,
		},function(){
			if(url){
				dialog.jump(url);
			}
		});
	},
	/*确认框 顶层窗口*/
	confirm:function(jsonData){
		if(dialog.isTopWin(window)){
			dialog.confirmMsg(jsonData);
		}else{
			window.top.iframe.parent.dialog.confirmMsg(jsonData);
		}
	},
	/*确认框*/
	confirmMsg:function(jsonData){
		layer.confirm(jsonData.message, {
		  btn: ['确定','取消']
		}, function(){
		  	jsonData.success && jsonData.success();
		},function(){
			jsonData.cancel && jsonData.cancel();
		});
	},
	jump:function(url){
		$('.iframe').attr('src',url);
	},
	/*页面层  顶层窗口*/
	pageshowTop:function(title,url,w,h){
		if(dialog.isTopWin(window)){
			dialog.pageshow(title,url,w,h);
		}else{
			window.top.iframe.parent.dialog.pageshow(title,url,w,h);
		}
	},
	/*页面层*/
	//w:800px,h:400px
	pageshow:function(title,url,w,h){
		if (title == null || title == '') {
			title=false;
		};
		if (url == null || url == '') {
			url="404.html";
		};
		if (w == null || w == '') {
			w='800px';
		};
		if (h == null || h == '') {
			h=($(window).height() - 100)+'px';
		};
		if(dialog.isTopWin(window)){
			layer.open({
				type: 2,
				area: [w, h],
				fix: false, //不固定
				maxmin: true,
				title: title,
				content: url,
				
			});
		}else{
			window.top.iframe.parent.layer.open({
				type: 2,
				area: [w, h],
				fix: false, //不固定
				maxmin: true,
				title: title,
				content: url,
				
			});
		}
		
	},
	/**跳转页面
	 * @param {Object} url
	 * @param {Object} bool  true顶层窗口   false   父级窗口
	 */
	goPage:function(url,bool){
		if(bool==true){
		 	window.top.iframe.parent.dui.creatIframe(url);
		}else{
			parent.dui.creatIframe(url);
		}
	},
	/*判断是不是顶层iframe*/
	isTopWin:function(win){
		if(win.parent==window){
			return true;
		}else{
			return false;
		}
	}
}
