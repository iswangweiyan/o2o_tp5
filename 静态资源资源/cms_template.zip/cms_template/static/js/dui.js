var dui=(function(){
	
	var init=function(){
		leftMenu();
	}
	var DOM={
		menuBox:$('.left-bar-menu'),
		menuBoxLi:$('.left-bar-menu').find('li'),
		menuBtn:$('.menu-btn'),
		rightContainer:$('.right-container'),
		iframeBox:$('.iframebox'),
		iframe:$('.iframe'),
		body:$('body'),
	}
	var leftMenu=function(){
		$.Huifold(".left-bar-menu dt",".left-bar-menu dd","fast",2,"click"); /*5个参数顺序不可打乱，分别是：相应区,隐藏显示的内容,速度,类型,事件*/
		DOM.menuBoxLi.on('click','a',function(e){
			e.preventDefault();
			var link=$(this).attr('rel');
			DOM.body.removeClass('big-page');
			DOM.menuBoxLi.removeClass('on');
			$(this).parent().addClass('on');
			dialog.jump(link);
		})
		DOM.menuBtn.on('click',function(){
			if(DOM.body.attr('class')=='big-page'){
				DOM.body.removeClass('big-page');
			}else{
				DOM.body.addClass('big-page');
			}
			
		})
	}
	/**
	 * 创建iframe
	 * @param {Object} url
	 */
	var creatIframe=function(url){
		//进度条开始加载
		NProgress.start();
		var iframe = document.createElement("iframe");
		$('.iframe').addClass('oldFrame');
		
		iframe.src = url;
		iframe.className='iframe';
		iframe.setAttribute('name','iframe');
		iframe.setAttribute('frameborder','0');
		iframe.setAttribute('scrolling','auto');
		iframe.setAttribute('width','100%');
		iframe.setAttribute('height','100%');
		if (iframe.attachEvent){
		    iframe.attachEvent("onload", function(){
		    	NProgress.done();
		    	$('.oldFrame').remove();
		    });
		} else {
		    iframe.onload = function(){
		    	NProgress.done();
		        $('.oldFrame').remove();
		    };
		}
		DOM.iframeBox.get(0).appendChild(iframe);
	}
	/*var indexIframeLoad=function(){
		NProgress.start();
		var mFrame=DOM.iframe.get(0);
		if (mFrame.attachEvent){
		    mFrame.attachEvent("onload", function(){
		    	NProgress.done();
		    });
		} else {
		    mFrame.onload = function(){
		    	NProgress.done();
		    };
		}
	}*/
	var isTopWin=function(win){
		if(win.parent==window){
			return true;
		}else{
			return false;
		}
	}
	return {
		init:init,
		isTopWin:isTopWin
	}
})()
